import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';


function Edit() {
  
  const [values, setValues] = useState({ })
  
  const Change = (e) => {setValues({...values, [e.target.name]: e.target.value})}

  const subfn = (e) => {
    console.log(e)
    e.preventDefault()
    console.log(values)
    axios.post(`http://localhost:4003/edit/${id}`,values)
      .then((a) => {
        if (a.status === 200) {
          alert("Updated Sucessfully")
      
        }

        console.log(a)
      })
      .catch((e) => {
        alert("error")
        console.log(e)
      })
  }


    const id=localStorage.getItem('userid')
    console.log(id)

   useEffect(()=>{
    axios.post(`http://localhost:4003/viewuser/${id}`)
        .then((res) =>{
          console.log(res,"res");
        if(res.data.data!=undefined){
            setValues(res.data.data)
        }
      })
    .catch((e) => {
              //alert("error")
            // console.log(e)
          })
        },[ ])
  return (
    <div> <Navbar bg="dark" data-bs-theme="dark">
    <Container>
      <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
      <Nav className="me-auto">
      <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/UserHome'>Home</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Resume'>Resume</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Edit'>Edit</Link></Nav.Link>
        <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Logout</Link></Nav.Link>
      </Nav>
    </Container>
  </Navbar>
  
  <div>
{/* 
  <form onSubmit={Submit}>
        <h2>Profile Details</h2><hr></hr>
        <p>
        Name = <input type='text'  value={values.name} onChange={Change} name="name"/><br></br>
        Address =<input type='textarea'  value={values.address} onChange={Change} name="address"/><br></br>
        Email =    <input type='text'  value={values.email} onChange={Change} name="email"/><br></br>
        Password = <input type='text'  value={values.password} onChange={Change} name="password"/><br></br>
        <br></br>
        <button className='submit' type='Submit' >Submit </button>
        </p>
        </form> */}
        <div className="col-10">
            <div>
              <div class="page-wrapper font-poppins">
                <div className="formcontainer" style={{margin:"50px"}}>
                  <div class="wrapper wrapper--w480">
                    <div class="card card-10">
                      <div class="card-body">
                        <h2 class="title">Edit your Resume</h2>
 <form onSubmit={subfn}>
                          <div class="row row-space">
                            <div class="col-12">
                              <div class="input-group">
                                <label class="label"> Name : </label>
                                <input
                                  class="input--style-6"
                                  type="text"
                                  name="name"
                                  value={values.name}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>
                            <div class="col-12">
                              <div class="mb-3">
                                <label
                                  for="exampleFormControlTextarea1"
                                  class="form-label"
                                >
                                Address
                                </label>
                                <textarea
                                  class="form-control"
                                  name="address"
                                  onChange={Change}
                                  required
                                  value={values.address}
                                  id="exampleFormControlTextarea1"
                                  rows="3"
                                ></textarea>
                              </div>
                            </div><br/><br/> 

                            <div class="col-12">
                              <div class="input-group">
                                <label class="label"> Contact :</label>
                                <input
                                  class="input--style-4"
                                  type="tel"
                                  minLength="10"
                                  maxLength="10"
                                  name="phone"
                                  value={values.phone}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>

                            <div class="col-12">
                              <div class="input-group">
                                <label class="label"> Age :</label>
                                <input
                                  class="input--style-4"
                                  type="number"
                                  minLength="10"
                                  maxLength="10"
                                  name="phone"
                                  value={values.age}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>

                            <div class="col-12">
                              <div class="input-group">
                                <label class="label"> Email : </label>
                                <input
                                  class="input--style-4"
                                  type="email"
                                  name="email"
                                  value={values.email}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>
                           
                            <div class="col-12">
                              <div class="input-group">
                                <label class="label">Age :</label>
                                <input
                                  class="input--style-4"
                                  type="number"
                                  name="age"
                                  min="1"
                                  value={values.age}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>
                            
                            <div class="col-12">
                              <div class="input-group">
                                <label class="label">Skills :</label>
                                <input
                                  class="input--style-4"
                                  type="text"
                                  name="skills"
                                  value={values.skills}
                                  onChange={Change}
                                  required
                                />
                              </div>
                            </div><br/><br/>
        
                            
                            <div class="col-12">
                              <div class="mb-3">
                                <label for="formFile" class="form-label">
                                  Upload your Image
                                </label>
                                <input
                                  class="form-control"
                                  type="file"
                                  id="formFile"
                                  name="img"
                                  required
                                  onChange={Change}
                                />
                              </div>
                            </div>
                          </div>
                          <div class="p-t-15">
                            <button class="btn btn-primary" type="submit">
                              Submit
                            </button>
                          </div>
                        </form>
                        </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



  </div>
  </div>
  )
}

export default Edit