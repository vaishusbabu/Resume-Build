import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';


function Home() {
  return (
    <div>
        
        <Navbar bg="dark" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Home</Link></Nav.Link>
            <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Register'>Register</Link></Nav.Link>
            <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/Login'>Login</Link></Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <div >
<img src="https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8cmVzdW1lfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80" width ="1270" ></img>
       
       </div>
     
    </div>
  )
}

export default Home