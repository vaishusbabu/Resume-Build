import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

function UserHome() {
  return (
    <div>  <Navbar bg="dark" data-bs-theme="dark">
    <Container>
      <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
      <Nav className="me-auto">
        <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/UserHome'>Home</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Resume'>Resume</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Edit'>Edit</Link></Nav.Link>
        <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Logout</Link></Nav.Link>
      </Nav>
    </Container>
  </Navbar>

        <h3>Welcome </h3>
    </div>
  )
}

export default UserHome