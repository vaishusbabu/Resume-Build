import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';


function Resume() {

  const [values, setValues] = useState({image: [{ filename: "" }]})

  

    const id=localStorage.getItem('userid')
    console.log("userid",id)

   useEffect(()=>{
    axios.post(`http://localhost:4003/viewuser/${id}`)
        .then((res) =>{
          console.log(res,"res");
        if(res.data.data!=undefined){
            setValues(res.data.data)
        }
      })
    .catch((e) => {
              //alert("error")
            // console.log(e)
          })
        },[ ])

      //  console.log(values.img.filename);
        
  return (
    <div>
      
      <Navbar bg="dark" data-bs-theme="dark">
    <Container>
      <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
      <Nav className="me-auto">
      <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/UserHome'>Home</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Resume'>Resume</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Edit'>Edit</Link></Nav.Link>
        <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Logout</Link></Nav.Link>
      </Nav>
    </Container>
  </Navbar>

 {/* <div class="col-4">
        <div class="card" style={{ width: "60rem",margin:"30%",textAlign:"center"}}>
        <div class="card-body"> */}   
        <div className='res'> 
        <div className="container">
        <div className="row">
          <div className="col-6">
            <div class="card card-body" style={{ width: "56rem",margin:"15%"}}>
              
                <div class="card" >
                  <div class="card-body">
                    <h1 class="card-title"></h1>
                            {
                            values.img?( <img src={`http://localhost:4003/${values.img.originalname}`} height="150p" width="130px"style={{borderRadius:"70%",margin:"10px"}} />):<p>no image</p>
                            }
                          <h5 class="card-title" style={{color:"darkblue"}}>Name : {values.name}</h5><hr/>
                          <h6 class="card-text">Address : {values.address}</h6><hr/>
                          <h6 class="card-text">Contact : {values.phone}</h6><hr/>
                          <h6 class="card-text">Email : {values.email}</h6><hr/>
                          <h6 class="card-text">Age : {values.age}</h6><hr/>
                          <h6 class="card-text">Qualification : {values.qualification}</h6><hr/>
                          <h6 class="card-text">Skills : {values.skills}</h6><hr/>
                          <h6 class="card-text">Experience : {values.experience}</h6>                  
                  </div>
                </div>
            </div>
          </div>
      </div>
      </div>
      </div>
    </div>
  )
}

export default Resume