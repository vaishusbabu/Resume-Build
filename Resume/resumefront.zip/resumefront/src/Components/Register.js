import React, { useState } from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Form from 'react-bootstrap/Form';
import { Link, useNavigate } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import axios from 'axios';

function Register() {
  const Navigate =useNavigate()
  const [values,setValues]=useState({
    name:"",
    place:"",
    email:"",
    age:"",
    gender:"",
    qualification:"",
    skills:"",
    experience:"",
    password:"",
    img:null,

  })
  const Change=(e)=>{
    if (e.target.name == "img") {
      setValues({ ...values, img: e.target.files[0] });
    } else {
      setValues({ ...values, [e.target.name]: e.target.value });
    }
  };

  const Submit=(e)=>{
    console.log(e)
    e.preventDefault()
    console.log(values)
    axios.post("http://localhost:4003/adduser",values,
    {
      headers:{
        "Content-Type":"multipart/form-data",
      },
    }
    )
    
    .then((a)=>{
      if(a.status===200)
      {
        alert("Registered Sucessfully")
        Navigate("/")
      }
      console.log(a)
    })
    .catch((e)=>{
      alert("Error")
      console.log(e)
    })
  }

  return (
    <div>
         <Navbar bg="dark" data-bs-theme="dark">
    <Container>
      <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
      <Nav className="me-auto">
        <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Home</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Register'>Register</Link></Nav.Link>
        <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/Login'>Login</Link></Nav.Link>
      </Nav>
    </Container>
  </Navbar>
<br/><br/>
<div className='reg'>
<Form onSubmit={Submit} >
            <br></br>
            <h3>Enter your Details</h3>
            <hr></hr>
            <br></br>
          <Form.Group className="mb-3" controlId="formGroupEmail"  >
                <Form.Label>Name :</Form.Label>
                <Form.Control type="text" placeholder="Enter your Name" onChange={Change}  name ="name" />
          </Form.Group>
               <Form.Group className="mb-3" controlId="formGroupPassword">
                <Form.Label>Address :</Form.Label>
                <Form.Control type="text" placeholder="Enter your Address" onChange={Change} name="address" /><br/>
          </Form.Group>
                <Form.Group className="mb-3" controlId="formGroupEmail"  >
                <Form.Label>Phone No :</Form.Label>
                <Form.Control type="number" maxLength={10} placeholder="Enter your Phone No" onChange={Change}  name ="phone" />
          
          </Form.Group>
                <Form.Group className="mb-3" controlId="formGroupEmail">
                <Form.Label>Email :</Form.Label>
                <Form.Control type="email" placeholder="Enter your email" onChange={Change} name="email" />
          </Form.Group>
                <Form.Group className="mb-3" controlId="formGroupEmail">
                <Form.Label>Age :</Form.Label>
                <Form.Control type="number" placeholder="Enter your age" onChange={Change} name="age" />
          </Form.Group>
     
     <div class='radio'>
                <Form>
                    {[ 'radio'].map((type) => (
                      <div key={`inline-${type}`} className="mb-3">
                        <Form.Check
                          inline
                          label="Female"

                          name="group1"
                          type={type}
                          id={`inline-${type}-1`}
                        />
                        <Form.Check
                          inline
                          label="Male"
                          name="group1"
                          type={type}
                          id={`inline-${type}-2`}
                        />         
                      </div>
                    ))}
                  </Form>
    </div>
          
    <Form.Group className="mb-3" controlId="formGroupPassword">
                <Form.Label>Qualification :</Form.Label>
                <Form.Control type="text" placeholder="Enter your Qualification" onChange={Change} name="qualification" />
                </Form.Group>
    <Form.Group className="mb-3" controlId="formGroupPassword">
                <Form.Label>Skills :</Form.Label>
                <Form.Control type="text" placeholder="Enter your skills" onChange={Change} name="skills" />
                </Form.Group>
    <Form.Group className="mb-3" controlId="formGroupPassword">
                <Form.Label>Experience :</Form.Label>
                <Form.Control type="number" placeholder="Enter your Experience" onChange={Change} name="experience" />
                </Form.Group>
    <Form.Group className="mb-3" controlId="formGroupPassword">
                <Form.Label>Password :</Form.Label>
                <Form.Control type="password" placeholder="Enter your Password" onChange={Change} name="password" />
                </Form.Group>
                <Form.Group controlId="formFile" className="mb-3">   
        <Form.Control type="file" onChange={Change}  name ="img"/>
      </Form.Group>
                <br></br>
                <Button variant="dark" type='Submit'>Submit</Button>
              
            </Form>
            </div>
    </div>
  )
}

export default Register