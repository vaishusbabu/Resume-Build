import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import {useNavigate} from 'react-router-dom';
import axios from 'axios'
import React, { useState } from 'react';

function Login() {
  const Navigate = useNavigate()
    
  const [values, setValues] = useState({
  email: "",
  password: ""
  })
  const Change = (e) => {
  setValues({
  ...values, [e.target.name]: e.target.value

  })
  }

  const Submit=(e)=>{
    console.log(e)
    e.preventDefault()
    axios.post("http://localhost:4003/login",values)
    .then((a) =>{
      if (a.data.status === 200) {
         // alert("Login Sucessull")
          Navigate("/Resume")
          localStorage.setItem("userid",a.data.data._id)        //storing data to local storage
      }
      console.log(a)
  })
  .catch((e) => {
      alert("error")
      console.log(e)
  })
  }

  return (
    <div>
 <div>
  <div>
  <Navbar bg="dark" data-bs-theme="dark">
    <Container>
      <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
      <Nav className="me-auto">
        <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Home</Link></Nav.Link>
        <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Register'>Register</Link></Nav.Link>
        <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/Login'>Login</Link></Nav.Link>
      </Nav>
    </Container>
  </Navbar>


    <br />
  </div>
        </div>
        <div className='main'>
      <Form onSubmit={Submit} >
          <br></br>
          <h3>  Log In</h3>
          <hr></hr>
          <br></br>
        <Form.Group className="mb-3" controlId="formGroupEmail"  >
          <Form.Label>Email address</Form.Label>
          <Form.Control type="email" placeholder="Enter email" onChange={Change} name="email" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formGroupPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" placeholder="Password" onChange={Change}  name="password"/>
          <br></br>
          <Button variant="dark"  className='submit' type="Submit">LOGIN</Button>
        </Form.Group>
      </Form>
      </div>
    </div>
  )
}

export default Login





























// import axios from 'axios';
// import { Button } from 'bootstrap';
// import React, { useState } from 'react'
// import Container from 'react-bootstrap/Container';
// import Nav from 'react-bootstrap/Nav';
// import Navbar from 'react-bootstrap/Navbar';
// import { Form, Link, useNavigate } from 'react-router-dom';


// function Login() {
//     const Navigate = useNavigate()
    
//   const [values, setValues] = useState({
//   email: "",
//   password: ""
//   })
//   const Change = (e) => {
//   setValues({
//   ...values, [e.target.name]: e.target.value

//   })
//   }

//   const Submit=(e)=>{
//     console.log(e)
//     e.preventDefault()
//     axios.post("http://localhost:4003/login",values)
//     .then((a) =>{
//       if (a.data.status === 200) {
//          // alert("Login Sucessull")
//           Navigate("/UserHome")
//           localStorage.setItem("userid",a.data.data._id)       
//       }
//       console.log(a)
//   })
//   .catch((e) => {
//       alert("error")
//       console.log(e)
//   })
//   }
//   return (
//     <div>
        
//         <Navbar bg="dark" data-bs-theme="dark">
//         <Container>
//           <Navbar.Brand href="#home">Resume Builder</Navbar.Brand>
//           <Nav className="me-auto">
//             <Nav.Link href="#home"><Link class="btn btn-outline-light" aria-current="page" to ='/'>Home</Link></Nav.Link>
//             <Nav.Link href="#features"><Link class="btn btn-outline-light" aria-current="page" to ='/Register'>Register</Link></Nav.Link>
//             <Nav.Link href="#pricing"><Link class="btn btn-outline-light" aria-current="page" to ='/Login'>Login</Link></Nav.Link>
//           </Nav>
//         </Container>
//       </Navbar>
//     <div>

//     <Form onSubmit={Submit} >
//           <br></br>
//           <h3>  Log In</h3>
//           <hr></hr>
//           <br></br>
//         <Form.Group className="mb-3" controlId="formGroupEmail"  >
//           <Form.Label>Email address</Form.Label>
//           <Form.Control type="email" placeholder="Enter email" onChange={Change} name="email" />
//         </Form.Group>
//         <Form.Group className="mb-3" controlId="formGroupPassword">
//           <Form.Label>Password</Form.Label>
//           <Form.Control type="password" placeholder="Password" onChange={Change}  name="password"/>
//           <br></br>
//           <Button variant="dark"  className='submit' type="Submit">LOGIN</Button>
//         </Form.Group>
//       </Form>
//     </div>
         
//     </div>
    
//   )
// }

// export default Login