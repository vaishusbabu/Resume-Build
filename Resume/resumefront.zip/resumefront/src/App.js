import 'bootstrap/dist/css/bootstrap.css';
import './App.css';
import Home from './Components/Home';
import Register from './Components/Register';
import Login from './Components/Login';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import UserHome from './Components/UserHome';
import Edit from './Components/Edit';
import Resume from './Components/Resume';

function App() {
  return (
    <div className="App">
    <BrowserRouter>
      <Routes>

            <Route path='/' element ={<Home/>}/>
            <Route path='/Register' element={<Register/>}/>
            <Route path='/Login' element={<Login/>}/>
            <Route path='/UserHome' element={<UserHome/>}/>
            <Route path='/Edit' element={<Edit/>}/>
            <Route path='/Resume' element={<Resume/>}/>
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
